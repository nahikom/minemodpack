<div align=center>
  <img src="./pack.png" width="128">
  <h2>Glowing</h2>

[![Modrinth Downloads](https://img.shields.io/modrinth/dt/glowing?color=00AF5C&label=downloads&style=round&logo=modrinth)](https://modrinth.com/resourcepack/glowing)
[![GitHub Downloads via the Releases section](https://img.shields.io/github/downloads/7777777-4547/glowing/total?style=round&logo=github)](https://github.com/7777777-4547/glowing)
[![CurseForge downloads](https://cf.way2muchnoise.eu/full_glowing_downloads.svg)](https://www.curseforge.com/minecraft/texture-packs/glowing)

  Use Optifine format let some blocks, items and entities glow.
  <h2>Showcase</h2>
<br/>
  <img src="https://raw.githubusercontent.com/7777777-4547/Glowing/img/img/2022-05-27_06.55.38.png">
<br/>
  <img src="https://raw.githubusercontent.com/7777777-4547/Glowing/img/img/2022-01-18_13.57.42.png">
<br/>
  <img src="https://raw.githubusercontent.com/7777777-4547/Glowing/img/img/2022-01-18_14.44.13.png">
<br/>
  <img src="https://raw.githubusercontent.com/7777777-4547/Glowing/img/img/2021-12-30_19.43.27.png">
<br/>
  <img src="https://raw.githubusercontent.com/7777777-4547/Glowing/img/img/2021-12-30_20.18.06.png">
<br/>
  <img src="https://raw.githubusercontent.com/7777777-4547/Glowing/img/img/2022-01-18_14.55.21.png">
<br/>
  <img src="https://raw.githubusercontent.com/7777777-4547/Glowing/img/img/2022-01-01_19.40.22.png">
<br/>
  <img src="https://raw.githubusercontent.com/7777777-4547/Glowing/img/img/2022-06-11_20.31.32.png">
<br/>
  <img src="https://raw.githubusercontent.com/7777777-4547/Glowing/img/img/GIF 2022-4-16 23-09-59.gif" height="325">
</div>
